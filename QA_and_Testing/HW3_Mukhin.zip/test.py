import unittest
import math
import doub
from AdvSqrt import AdvSqrt


class TestAdvSqrt(unittest.TestCase):

    def setUp(self):
        self.advSqrt = AdvSqrt()

    def test_sqrt_nan(self):
        # Тест: sqrt(NaN) -> NaN
        input_val = doub.NAN
        result = self.advSqrt.sqrt(input_val)
        self.assertTrue(math.isnan(result), "sqrt(NaN) должна возвращать NaN")

    def test_sqrt_negative_number(self):
        # Тест: sqrt(отрицательного числа, кроме -0) -> NaN
        input_val = -4.0
        result = self.advSqrt.sqrt(input_val)
        self.assertTrue(math.isnan(result), "sqrt(отрицательного числа) должна возвращать NaN")

    def test_sqrt_negative_zero(self):
        # Тест: sqrt(-0.0) -> -0.0 (проверка по битовому представлению)
        input_val = -0.0
        result = self.advSqrt.sqrt(input_val)
        expected_bits = doub.doubleToRawLongBits(-0.0)
        result_bits = doub.doubleToRawLongBits(result)
        self.assertEqual(result_bits, expected_bits, "sqrt(-0.0) должна возвращать -0.0")

    def test_sqrt_positive_zero(self):
        # Тест: sqrt(0.0) -> 0.0
        input_val = 0.0
        result = self.advSqrt.sqrt(input_val)
        self.assertEqual(result, 0.0, "sqrt(0.0) должна возвращать 0.0")

    def test_sqrt_one(self):
        # Тест: sqrt(1.0) -> 1.0
        input_val = 1.0
        result = self.advSqrt.sqrt(input_val)
        self.assertEqual(result, 1.0, "sqrt(1.0) должна возвращать 1.0")

    def test_sqrt_positive_infinity(self):
        # Тест: sqrt(+∞) -> +∞
        input_val = doub.POSITIVE_INFINITY
        result = self.advSqrt.sqrt(input_val)
        self.assertEqual(result, doub.POSITIVE_INFINITY, "sqrt(+∞) должна возвращать +∞")

    def test_sqrt_normalized_number(self):
        # Тест: sqrt(4.0) -> 2.0 (нормализованное число)
        input_val = 4.0
        result = self.advSqrt.sqrt(input_val)
        self.assertEqual(result, 2.0, "sqrt(4.0) должна возвращать 2.0")

    def test_sqrt_non_perfect_square(self):
        # Тест: sqrt(2.0) сравнивается с math.sqrt(2.0)
        input_val = 2.0
        result = self.advSqrt.sqrt(input_val)
        expected = math.sqrt(input_val)
        # Используем допуск, равный одному ULP
        self.assertAlmostEqual(result, expected, delta=math.ulp(expected),
                               msg=f"sqrt(2.0) должна быть близка к {expected} (с допуском 1 ULP)")

    def test_sqrt_denormalized_number(self):
        # Тест: sqrt(Double.MIN_VALUE) для денормализованного числа
        input_val = doub.MIN_VALUE
        result = self.advSqrt.sqrt(input_val)
        expected = math.sqrt(input_val)
        self.assertAlmostEqual(result, expected, delta=math.ulp(expected),
                               msg=f"sqrt(Double.MIN_VALUE) должна быть близка к {expected} (с допуском 1 ULP)")

    def test_sqrt_value_near_denormal_boundary(self):
        # Тест: значение, меньше границы нормализации (dnrbnd), чтобы проверить обработку денормализованных чисел.
        input_val = AdvSqrt.dnrbnd * 0.5
        result = self.advSqrt.sqrt(input_val)
        expected = math.sqrt(input_val)
        self.assertAlmostEqual(result, expected, delta=math.ulp(expected),
                               msg=f"sqrt({input_val}) должна быть близка к {expected} (с допуском 1 ULP)")


if __name__ == '__main__':
    unittest.main()
